from transformers import pipeline

# Load saved model
classifier = pipeline(
    "sentiment-analysis",
    model="./model",
    tokenizer="./model"
)

# Batch samples
samples = [
    "I love this movie",
    "This movie is terrible",
    "Amazing acting and story",
    "Worst film ever"
]

# Predictions
results = classifier(samples)

# Print results
for text, result in zip(samples, results):

    print("Text:", text)
    print("Prediction:", result)
    print()