from flask import Flask, request, jsonify
from transformers import pipeline

# Create Flask app
app = Flask(__name__)

# Load trained model
classifier = pipeline(
    "sentiment-analysis",
    model="./model",
    tokenizer="./model"
)

# API route
@app.route("/predict", methods=["POST"])
def predict():

    # Get JSON data
    data = request.json

    # Extract text
    text = data["text"]

    # Prediction
    result = classifier(text)

    # Return result
    return jsonify(result)

# Run app
if __name__ == "__main__":
    app.run()